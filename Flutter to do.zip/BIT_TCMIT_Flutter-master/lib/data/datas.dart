const TAB_BAR_DATA = [
  {
    "name": "All",
  },
  {"name": "Politics"},
  {"name": "Economcis"},
  {"name": "Sports"},
  {"name": "Sports"},
];
